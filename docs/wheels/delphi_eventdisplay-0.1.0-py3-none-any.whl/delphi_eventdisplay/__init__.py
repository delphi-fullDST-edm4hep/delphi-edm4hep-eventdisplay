"""DELPHI event display from edm4hep, drawn with Plotly.

    from delphi_eventdisplay import read_event, build
    fig = build(read_event("Y13709.126.edm4hep.root", 3990))
    fig.write_html("event.html")

The command line does the same: `delphi-display FILE --entry N --out event.html`.
"""

from .figure import build
from .read import Event, n_entries, read_event

__version__ = "0.1.0"
__all__ = ["Event", "build", "n_entries", "read_event"]
